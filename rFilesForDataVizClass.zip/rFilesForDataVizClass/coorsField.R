###read in baseball data
## uncomment the below if you need to install these two packages for the first time
#install.packages("ggplot2")
library(dplyr)
library(ggplot2)

##

###let's see if Coors field is a "run-friendly" baseball park
browseURL("http://en.wikipedia.org/wiki/Coors_Field")


###the following line loads data from the 2010 - 2014 baseball seasons.  The following data gets loaded:
# Date      :     The date the baseball game was played
# Home      :     A three letter code indicating the "home" team
# Visitor   :     A three letter code indicating the "visiting" team
# HomeScore :     # of runs scored by the home team
# VisitorScore :  # of runs scored by the visiting team
###note: If HomeScore > VisitorScore, then the Home team wins the game.
###      If HomeScore < VisitorScore, then the Visitor team wins the game.
load("baseball.RData")   ###ensure this file is in your working directory

####Manipulate Data to Match Purpose
baseballData2 = baseballData %>% 
  mutate(totalRuns = HomeScore + VisitorScore) %>% 
  group_by(Home) %>% 
  summarise(avgRuns = mean(totalRuns)) %>% 
  arrange(desc(avgRuns))

### Let's choose our axes to be the two most important content features
### we do this via aesthtic mapping (see cheatsheet)
ggplot(data = baseballData2, aes(x = Home, y = avgRuns))

## mapping points to aethetic using plot default
## of x = Home and y = avgRund
ggplot(data = baseballData2, aes(x = Home, y = avgRuns)) +
  geom_point()

ggplot(data = baseballData2) + ## mapping just for pts
  geom_point(aes(x = Home, y = avgRuns))  

###Change structure to highlight the differences
ggplot(data = baseballData2, aes(x = Home, y = avgRuns)) +
  geom_bar(stat = "identity")

###Explore reversing the axes
ggplot(data = baseballData2, aes(x = Home, y = avgRuns)) +
  geom_bar(stat = "identity") + 
  coord_flip()

###Highlight Coors Field - need data first!!
baseballData3 = baseballData2 %>% 
  mutate(CoorsField = ifelse(Home == "COL","Coors Field","Other Stadium"))

### then map data to a plot aesthetic
ggplot(data = baseballData3, 
       aes(x = Home, 
           y = avgRuns, 
           fill = CoorsField)) +
  geom_bar(stat = "identity") + coord_flip()

###try with reordering vertical axis labels (i.e. x-axis due to coord_flip()
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           fill = CoorsField)) + 
  geom_bar(stat = "identity") + 
  coord_flip()

###work on formatting... try points instead of bars
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           fill = CoorsField)) + 
  geom_point() + ## different line
  coord_flip()

###color the points
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           color = CoorsField)) + 
  geom_point() + 
  coord_flip()

###make the points bigger
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           color = CoorsField)) + 
  geom_point(size = 4) + 
  coord_flip()

###add thin bars to points
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           color = CoorsField)) + 
  geom_point(size = 4) + 
  coord_flip() + 
  geom_bar(stat="identity",
           fill = "black", 
           color = "black", 
           width = 0.01)

###plot points on top of lines
ggplot(data = baseballData3, 
       aes(x = reorder(Home,avgRuns), 
           y = avgRuns, 
           color = CoorsField)) + 
  geom_bar(stat="identity",
           fill = "black", 
           color = "black", 
           width = 0.001) + 
  geom_point(size = 4) + 
  coord_flip()

###save plot to an object and then add some title information
myPlot = ggplot(data = baseballData3, 
                aes(x = reorder(Home,avgRuns), 
                    y = avgRuns, 
                    color = CoorsField)) + 
  geom_bar(stat="identity",
           fill = "black", 
           color = "black", 
           width = 0.001) + 
  geom_point(size = 4) + 
  coord_flip()

###add label information
myPlot2 = myPlot + 
  ggtitle("How Run Friendly is Colorado's Coors Field?") +
  xlab("Ballpark") + 
  ylab("Avergage Number of Runs Per Game") 

myPlot2 

## try different themes
# install.packages("ggthemes") # Install 
library(ggthemes) # Load
myPlot2 + ## ggplot function to give last plot
  theme_economist() + 
  scale_color_economist()

## others to explore
myPlot2 + theme_stata() + scale_color_stata()
myPlot2 + theme_wsj()+ scale_colour_wsj("colors6")
  
###The formatting can be tweaked even further, but we will stick to spending our time on purpose, content, and structure.    

###try another way just for fun .. use density to show more probable scores ... this plot might be better for a statistician than a manager.  Always know your audience
newData = baseballData %>% 
  mutate(CoorsField = ifelse(Home == "COL",
                             "Coors Field",
                             "Other Stadium")) %>% 
  mutate(totalRuns = HomeScore + VisitorScore)

## this is a terrible plot for a general audience
ggplot(data = newData, 
       aes(x=HomeScore, 
           fill = CoorsField)) + 
  geom_density(alpha=.5)
