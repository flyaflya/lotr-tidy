library("dplyr")
library("ggplot2")
library("hflights")

?hflights

### get the data we need to assess delay by day of the week and carrier
delayByCarrier = hflights %>%
  select(day = DayOfWeek, ###give columns better names
         airline = UniqueCarrier, 
         delay = ArrDelay)

str(delayByCarrier)

### Mappings:
#x-axis: Airline
#y-axis: Delay
#color: day
# dplyr::sample_frac used because 200,000 data pts is too many to plot
ggplot(data=delayByCarrier %>% sample_frac(size = 0.1),
       mapping=aes(x=airline,y=delay,color = day)) +
  geom_point()

ggplot(data=delayByCarrier %>% sample_frac(size = 0.1),
       mapping=aes(x=airline,y=delay,color = day)) +
  facet_grid(day ~ airline) + 
  geom_point()

##some times when there is so much information, all insight gets lost
delayByCarrier2 = 
  delayByCarrier %>%
    mutate(delayFlag = ifelse(delay <= 0,0,1)) %>%
    group_by(day,airline) %>%
    summarise(PctDelayed = mean(delayFlag, na.rm=TRUE), count = n()) %>%
    filter(count > 20) %>%
    arrange(desc(PctDelayed))

###one way to cut down the information in each chart is by using facets
ggplot(delayByCarrier2,
       aes(x=airline, y= PctDelayed)) + 
  geom_bar(stat="identity") + 
  facet_grid(day~.)

###this still is not great... what else can we do to help us understand if the percentage delay by airline fluctuates during the course of a week
ggplot(delayByCarrier2,
       aes(x=airline, y= PctDelayed, color = as.factor(day))) + 
  geom_point() +
  coord_flip()

###let's go with larger points and order the x-axis (which is really the vertical axis due to the flip
ggplot(delayByCarrier2,
       aes(x=airline, y= PctDelayed, color = as.factor(day))) + 
  geom_point(size = 4) +
  coord_flip()

ggplot(delayByCarrier2,
       aes(x=as.factor(day), y= PctDelayed, color = airline)) + 
  geom_point(size = 4) +
  coord_flip()

ggplot(delayByCarrier2,
       aes(x=as.factor(day), y= PctDelayed, color = airline)) + 
  geom_point(size = 4)  + 
  geom_line()

ggplot(delayByCarrier2,
       aes(x=as.factor(day), y= PctDelayed, color = airline)) + 
  geom_point(size = 4)  + 
  geom_line(aes(group = airline))

###one last thing... maybe filter the data to airlines of interest
delayByCarrier3 = delayByCarrier2 %>% 
  filter(count > 500)

ggplot(delayByCarrier3,
       aes(x=as.factor(day), y= PctDelayed, color = airline)) + 
  geom_point(size = 4) + 
  geom_line(aes(group = airline))

###then take advantage of one last attribute (i.e. size) to show number of flights each day
ggplot(delayByCarrier3,
       aes(x=as.factor(day), y= PctDelayed, color = airline)) + 
  geom_point(aes(size = count)) + 
  geom_line(aes(group = airline)) + 
  scale_size(range = c(3, 10))
